package br.edu.cruzeirodosul.calculadora;

public class Calculadora {
    /**
     * calcula o valor da gorjeta dado o valor da conta e o  valor do percentual
     * @param conta o valor da conta
     * @param percentual o percentual da gorjeta
     * @return o valor da gorjeta
     */
    public static double gorjeta(double conta, double percentual){
        double saida = 0;

        saida = conta*percentual/100.0;

        return saida;
    }
    /**
     * calcula os valores das gorjetas padrao , de 5, 10 e 15%
     * @param conta o valor das conta
     * @return um vetor de 3 posiçoes com as gorjetas padrao
     */
    public static double[] gorjeta(double conta){
        double[] saida = new double[3];

        for (int i=0; i<3; i++){
            saida[i]=gorjeta(conta, i * 5 + 5);
        }

        return (saida);
    }
}
