package br.edu.cruzeirodosul.calculadora;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    //
    private static final String CONTA = "CONTA";
    private static final String PERCENTUAL ="PERCENTUAL";

    //atri
    private double conta;
    private double percentual;

    // atributos que armazenan referencia aos conponentes graficos

    EditText contaEditText;
    EditText gorjeta5EditText;
    EditText gorjeta10EditText;
    EditText gorjeta15EditText;
    SeekBar percentualSeekBar;
    EditText percentualEditText;
    EditText gorjetaEditText;

    //metodo executado no momento da criaçao da atividade
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // obtendo
        contaEditText =(EditText) findViewById(R.id.ContaEditText);
        gorjeta5EditText = findViewById(R.id.gorjeta5EditText);
        gorjeta10EditText = findViewById(R.id.gorjeta10EditText);
        gorjeta15EditText = findViewById(R.id.gorjeta15EditText);
        percentualSeekBar = findViewById(R.id.percentualSeekBar);
        percentualEditText = findViewById(R.id.percentualEditText);
        gorjetaEditText = findViewById(R.id.gorjetaEditText);

        // associaçao dos ouvintes de eventos
        contaEditText.addTextChangedListener(ouvinteContaEditText);
        percentualSeekBar.setOnSeekBarChangeListener(ouvintePercentualSeekbar);

        //recuperaçao dos valores
        if (savedInstanceState == null){
            conta = 0;
            percentual = 7.5;
        }else {
            conta = savedInstanceState.getDouble(CONTA);
            percentual = savedInstanceState.getDouble(PERCENTUAL);
        }
        contaEditText.setText(String.format("%.2f",conta));
        percentualSeekBar.setProgress((int) percentual);

    }

    /**
     * atualiza os metodos editTexts
     */
    private void atualizaGorjetas(){
        double[] gorjetas = Calculadora.gorjeta(conta);
        gorjeta5EditText.setText(String.format("%.2f",gorjetas[0]));
        gorjeta10EditText.setText(String.format("%.2f",gorjetas[1]));
        gorjeta15EditText.setText(String.format("%.2f",gorjetas[2]));
    }

    private void atualizarGorjetaPersonalizada(){
        double gorjeta = Calculadora.gorjeta(conta, percentual);
        gorjetaEditText.setText(String.format("%.2f",gorjeta));
    }

    private TextWatcher ouvinteContaEditText = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            // este metodo deve ser sobre escrito, mas nao é usado neste app
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            conta = Double.parseDouble(contaEditText.getText().toString());
            atualizaGorjetas();
            atualizarGorjetaPersonalizada();

        }

        @Override
        public void afterTextChanged(Editable editable) {
            // este metodo deve ser sobre escrito, mas nao é usado neste app

        }
    };
    private SeekBar.OnSeekBarChangeListener ouvintePercentualSeekbar = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
            percentual = percentualSeekBar.getProgress();
            percentualEditText.setText(String.format("%.0f",percentual));
            atualizarGorjetaPersonalizada();
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {
            // este metodo deve ser sobre escrito, mas nao é usado neste app

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            // este metodo deve ser sobre escrito, mas nao é usado neste app

        }
    };

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putDouble(CONTA, conta);
        outState.putDouble(PERCENTUAL, percentual);
    }
}
